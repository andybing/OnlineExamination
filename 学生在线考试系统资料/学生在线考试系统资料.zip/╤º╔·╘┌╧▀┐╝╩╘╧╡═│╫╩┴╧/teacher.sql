create table teacher(id varchar2(20),name varchar2(20),sex varchar2(2),location varchar2(20),password varchar2(20));
