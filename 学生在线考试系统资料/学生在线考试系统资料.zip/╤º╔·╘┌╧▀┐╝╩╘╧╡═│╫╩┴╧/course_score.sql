create table course_score(id varchar2(20),sid varchar2(20));
