create table course_student(id varchar2(20),sid varchar2(20));
