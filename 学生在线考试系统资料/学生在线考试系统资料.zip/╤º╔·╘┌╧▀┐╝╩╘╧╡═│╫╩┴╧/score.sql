create table score(id int primary key,score number,state varchar2(20));

create sequence seq_score start with 1 increment by 1;
