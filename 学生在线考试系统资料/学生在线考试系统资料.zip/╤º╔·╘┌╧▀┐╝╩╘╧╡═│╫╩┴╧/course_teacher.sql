create table course_teacher (id varchar(20),tid varchar2(20));

